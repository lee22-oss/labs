# Запуск: python win_sender.py            (PostMessage, асинхронно)
#         python win_sender.py send       (SendMessage, синхронно, ждёт обработки)
import win32gui
import win32con
import sys
import time

WM_MY_COMMAND = win32con.WM_USER + 1337
USE_SEND = len(sys.argv) > 1 and sys.argv[1] == "send"

print("[ОТПРАВИТЕЛЬ] Ищем окно приемника по зарегистрированному имени класса...")
hwnd = win32gui.FindWindow("SysProgHiddenReceiverClass", None)

if hwnd == 0:
    print("[ОШИБКА] Окно приемника не найдено в системе! Запустите сначала win_receiver.py.")
    sys.exit(1)

print(f"[ОТПРАВИТЕЛЬ] Цель найдена. HWND приемника: {hwnd}")
start = time.time()
if USE_SEND:
    print("[ОТПРАВИТЕЛЬ] Вызываем SendMessage: синхронная отправка сигнала 777 (ждём обработки)...")
    try:
        win32gui.SendMessage(hwnd, WM_MY_COMMAND, 777, 0)
    except Exception as e:
        print(f"[ОТПРАВИТЕЛЬ] SendMessage завершился исключением (приёмник уничтожил себя): {e}")
else:
    print("[ОТПРАВИТЕЛЬ] Вызываем PostMessage: отправляем асинхронный сигнал 777...")
    win32gui.PostMessage(hwnd, WM_MY_COMMAND, 777, 0)

print(f"[ОТПРАВИТЕЛЬ] Вызов вернул управление через {time.time() - start:.2f} с. Конец работы.")
