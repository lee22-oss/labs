#!/bin/bash
# Устанавливает всё нужное для лабораторных в WSL
if [ "$(id -u)" -eq 0 ]; then SUDO=""; else SUDO="sudo"; fi
$SUDO apt update
$SUDO apt install -y nasm build-essential python3 python3-pip strace netcat-openbsd net-tools iproute2 htop
pip3 install posix_ipc || pip3 install --break-system-packages posix_ipc
echo "Готово. Проверка:"; nasm -v; gcc --version | head -1; python3 -c "import posix_ipc; print('posix_ipc ok')"
