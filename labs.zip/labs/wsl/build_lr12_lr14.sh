#!/bin/bash
set -e
echo "== ЛР12: сборка asm_client =="
nasm -f elf64 asm_client.asm -o asm_client.o
ld asm_client.o -o asm_client
echo "== ЛР14: сборка libmylib.so =="
nasm -f elf64 mylib.asm -o mylib.o
gcc -shared mylib.o -o libmylib.so
ls -l asm_client libmylib.so
