# Запуск: python3 socket_server.py          (без SO_REUSEADDR, воспроизводит ошибку)
#         python3 socket_server.py reuse    (с SO_REUSEADDR, ошибки нет)
import socket
import sys
import os

PORT = 9999

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

if len(sys.argv) > 1 and sys.argv[1] == "reuse":
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    print("[СЕРВЕР] SO_REUSEADDR ВКЛЮЧЕН")
else:
    print("[СЕРВЕР] SO_REUSEADDR выключен")

print(f"[СЕРВЕР] Инициализация. Мой PID: {os.getpid()}")
server_socket.bind(('127.0.0.1', PORT))
server_socket.listen(1)
print(f"[СЕРВЕР] Сокет переведен в режим listen. Порт {PORT} зарезервирован в ядре.")

print("[СЕРВЕР] Вызов accept(). Поток сейчас уйдет в глубокий сон...")
client_socket, client_address = server_socket.accept()
print(f"[СЕРВЕР] Поток разбужен! Зафиксировано подключение от {client_address}")

print("[СЕРВЕР] Ожидание данных от клиента (вызов recv)...")
data = client_socket.recv(1024)
print(f"[СЕРВЕР] Данные получены из RX-буфера ядра: {data.decode('utf-8')}")

print("[СЕРВЕР] Закрываем соединение и освобождаем дескрипторы.")
client_socket.close()
server_socket.close()
