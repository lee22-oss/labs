section .data
    ; Секрет для шифрования (ключ XOR)
    encryption_key db 0x5A

section .text
    global asm_encrypt

; Функция: asm_encrypt(char* data, int length)
; System V AMD64 ABI: RDI = указатель на строку, RSI = длина
asm_encrypt:
    cmp rsi, 0
    jle .done

    xor rcx, rcx                ; RCX = индекс символа

.loop:
    ; PIC-адресация: адрес ключа считается относительно RIP
    mov al, [rel encryption_key]
    xor byte [rdi + rcx], al    ; XOR текущего символа с ключом
    inc rcx
    cmp rcx, rsi
    jl .loop

.done:
    ret

; убирает предупреждение линковщика про исполняемый стек
section .note.GNU-stack noalloc noexec nowrite progbits
